"use client";

import { useEffect, useMemo, useState } from "react";
import { useParams } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";

type ExclusiveGroup = {
  id: string;
  title: string;
  description: string | null;
  price: number;
  city: string | null;
  interest: string | null;
  platforms: string[];
  poster_url: string | null;
};

const PLATFORM_ICONS: Record<string, string> = {
  instagram: "📸",
  telegram: "✈️",
  whatsapp: "💬",
  gmail: "📧",
};

const PLATFORM_LABELS: Record<string, string> = {
  instagram: "Instagram",
  telegram: "Telegram",
  whatsapp: "WhatsApp",
  gmail: "Gmail (Any network)",
};

export default function ExclusiveGroupDetailPage() {
  const params = useParams<{ id: string }>();
  const id = params?.id;

  const [group, setGroup] = useState<ExclusiveGroup | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    async function load() {
      setLoading(true);
      const { data, error } = await supabase
        .from("exclusive_groups")
        .select("*")
        .eq("id", id)
        .maybeSingle();

      if (error) { console.error(error); setGroup(null); }
      else setGroup((data as any) || null);
      setLoading(false);
    }
    load();
  }, [id]);

  const tags = useMemo(() => {
    const out: string[] = [];
    if (group?.interest) out.push(group.interest);
    if (group?.city) out.push(group.city);
    return out;
  }, [group]);

  return (
    <main className="min-h-screen text-white">
      {/* Ultra-premium background */}
      <div className="fixed inset-0 -z-10 bg-[#06060A]">
        <div className="absolute inset-0 bg-[radial-gradient(1400px_700px_at_15%_5%,rgba(212,175,55,0.07),transparent_60%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(900px_500px_at_85%_30%,rgba(255,255,255,0.05),transparent_55%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(800px_400px_at_50%_90%,rgba(212,175,55,0.04),transparent_60%)]" />
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12 md:py-16">
        <a href="/exclusive" className="inline-flex items-center gap-2 text-sm text-white/60 hover:text-white transition">
          ← Back to Exclusive Groups
        </a>

        {loading ? (
          <p className="mt-6 text-sm text-white/50 animate-pulse">Loading...</p>
        ) : !group ? (
          <p className="mt-6 text-sm text-white/50">Exclusive group not found.</p>
        ) : (
          <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main content */}
            <div className="lg:col-span-2">
              <div className="inline-flex items-center gap-2 rounded-full border border-amber-500/20 bg-amber-500/8 px-3 py-1 text-xs text-amber-200/80 backdrop-blur">
                <span className="h-2 w-2 rounded-full bg-amber-400" />
                Exclusive group
              </div>

              <h1 className="mt-4 text-3xl sm:text-4xl md:text-5xl font-semibold tracking-tight">
                {group.title}
              </h1>

              <div className="mt-4 flex flex-wrap gap-2">
                {tags.map((t) => (
                  <span key={t} className="px-3 py-1 rounded-full border border-white/10 bg-white/5 text-xs text-white/70">{t}</span>
                ))}
                {group.platforms?.map((p) => (
                  <span key={p} className="px-3 py-1 rounded-full border border-amber-500/20 bg-amber-500/8 text-xs text-amber-300/80">
                    {PLATFORM_ICONS[p] || ""} {PLATFORM_LABELS[p] || p}
                  </span>
                ))}
              </div>

              {/* Poster */}
              <div className="mt-8 rounded-3xl overflow-hidden border border-white/8 bg-white/4 backdrop-blur flex justify-center">
                {group.poster_url ? (
                  <img
                    src={group.poster_url}
                    alt={group.title}
                    className="max-w-lg w-full h-auto object-contain"
                    loading="lazy"
                  />
                ) : (
                  <div className="w-full py-16 flex items-center justify-center text-white/30 text-5xl">✦</div>
                )}
              </div>

              {group.description && (
                <p className="mt-6 text-white/65 leading-relaxed">{group.description}</p>
              )}

              <div className="mt-8 rounded-3xl border border-white/8 bg-white/4 backdrop-blur p-6">
                <h2 className="text-lg font-semibold text-white/90">About this exclusive group</h2>
                <p className="mt-2 text-sm text-white/55">
                  Payment will be handled personally after your application is approved. This is a curated, member-only circle.
                </p>
              </div>
            </div>

            {/* CTA sidebar */}
            <div className="lg:col-span-3">
              <div className="mt-2 rounded-3xl border border-amber-500/15 bg-white/4 backdrop-blur overflow-hidden">
                <div className="px-4 sm:px-6 py-5 bg-black/20 border-b border-white/8">
                  <div className="text-xs text-amber-300/70 font-medium tracking-wider uppercase">Ready to apply?</div>
                  <div className="mt-1 text-sm text-white/65">Submit your application to proceed. Admin will review personally.</div>
                </div>

                <div className="px-4 sm:px-6 py-5">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                    {/* Price + Network box */}
                    <div className="flex items-stretch gap-3 flex-wrap">
                      <div className="rounded-2xl border border-amber-500/20 bg-black/30 px-5 py-4">
                        <p className="text-xs text-white/50">Entry Price</p>
                        <p className="mt-1 text-2xl font-bold text-amber-300">₹{group.price}</p>
                        <p className="mt-1 text-xs text-white/45">Pay after approval</p>
                      </div>

                      {group.platforms?.length > 0 && (
                        <div className="rounded-2xl border border-white/8 bg-black/30 px-5 py-4">
                          <p className="text-xs text-white/50">Network(s)</p>
                          <div className="mt-1 flex flex-col gap-1">
                            {group.platforms.map((p) => (
                              <span key={p} className="text-sm font-semibold text-white/85">
                                {PLATFORM_ICONS[p] || ""} {PLATFORM_LABELS[p] || p}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    <a
                      href={`/exclusive/${group.id}/apply`}
                      className="inline-flex items-center justify-center rounded-2xl px-6 py-3 font-semibold bg-white text-black hover:bg-amber-50 transition shadow-md"
                    >
                      Apply Now →
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}