"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";

type ExclusiveGroup = {
  id: string;
  title: string;
  price: number;
  platforms: string[];
};

type Profile = {
  id: string;
  name: string;
  payment_status: "pending" | "verified" | "rejected";
  is_member: boolean;
};

export default function ExclusiveApplyPage() {
  const params = useParams<{ id: string }>();
  const groupId = params?.id;

  const [group, setGroup] = useState<ExclusiveGroup | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<
    null | { type: "success" | "not_logged_in" | "not_member" | "error"; message: string }
  >(null);

  useEffect(() => {
    if (!groupId) return;

    async function load() {
      setLoading(true);

      // Load group
      const { data: groupData, error: groupErr } = await supabase
        .from("exclusive_groups")
        .select("id, title, price, platforms")
        .eq("id", groupId)
        .maybeSingle();

      if (groupErr) {
        console.error("Error loading exclusive group:", groupErr);
      } else {
        setGroup((groupData as any) as ExclusiveGroup);
      }

      // Load profile from localStorage
      const profileId = localStorage.getItem("cityring_profile_id");
      if (profileId) {
        const { data: profileData, error: profileErr } = await supabase
          .from("profiles")
          .select("id, name, payment_status, is_member")
          .eq("id", profileId)
          .maybeSingle();

        if (!profileErr && profileData) {
          setProfile((profileData as any) as Profile);
        }
      }

      setLoading(false);
    }

    load();
  }, [groupId]);

  async function submit() {
    if (!groupId || submitting) return;

    setSubmitting(true);
    setResult(null);

    try {
      // Check if logged in
      const profileId = localStorage.getItem("cityring_profile_id");
      if (!profileId || !profile) {
        setResult({
          type: "not_logged_in",
          message: "You need to be logged in to apply. Please login first.",
        });
        setSubmitting(false);
        return;
      }

      // Check membership
      const isActiveMember = profile.is_member === true && profile.payment_status === "verified";
      if (!isActiveMember) {
        setResult({
          type: "not_member",
          message: "You must be a verified member before applying to exclusive groups.",
        });
        setSubmitting(false);
        return;
      }

      // Save application
      const { error: appErr } = await supabase.from("exclusive_applications").insert({
        profile_id: profileId,
        exclusive_group_id: groupId,
        status: "pending",
      });

      if (appErr) {
        if ((appErr as any).code === "23505") {
          setResult({ type: "success", message: "✅ Already applied. Please wait for admin response." });
        } else {
          throw appErr;
        }
        setSubmitting(false);
        return;
      }

      setResult({ type: "success", message: "✅ Application sent successfully!" });
      setSubmitting(false);
    } catch (e: any) {
      console.error("Exclusive apply error:", e);
      setResult({ type: "error", message: e?.message || "Something went wrong." });
      setSubmitting(false);
    }
  }

  return (
    <main className="min-h-screen text-white">
      {/* Premium background (match Join/Home vibe) */}
      <div className="fixed inset-0 -z-10 bg-[#07070A]">
        <div className="absolute inset-0 bg-[radial-gradient(1200px_600px_at_20%_10%,rgba(255,255,255,0.10),transparent_60%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(900px_500px_at_80%_30%,rgba(255,255,255,0.08),transparent_55%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(900px_500px_at_50%_100%,rgba(255,255,255,0.06),transparent_60%)]" />
        <div className="absolute inset-0 opacity-30 bg-[linear-gradient(to_bottom,transparent,rgba(255,255,255,0.04))]" />
      </div>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12 md:py-16">
        <a
          href={`/exclusive/${groupId ?? ""}`}
          className="inline-flex items-center gap-2 text-sm text-white/70 hover:text-white transition"
        >
          <span className="text-white/60">←</span> Back
        </a>

        <div className="mt-6 flex items-end justify-between flex-wrap gap-6">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-white/80 backdrop-blur">
              <span className="h-2 w-2 rounded-full bg-blue-500/80" />
              Exclusive application
            </div>

            <h1 className="mt-4 text-2xl sm:text-3xl md:text-4xl font-semibold tracking-tight">Apply</h1>

            <p className="mt-2 text-white/70">
              {group ? (
                <>
                  Applying for <span className="font-semibold text-white">{group.title}</span>
                  <span className="text-white/45"> • </span>
                  Price: <span className="font-semibold text-white">₹{group.price}</span>
                </>
              ) : (
                "Loading group..."
              )}
            </p>
          </div>

          <div className="rounded-2xl border border-white/10 bg-white/5 backdrop-blur px-5 py-4">
            <p className="text-xs text-white/60">Status</p>
            <p className="mt-1 text-sm font-semibold text-white">Member-only</p>
            <p className="mt-1 text-xs text-white/55">Verified members can apply</p>
          </div>
        </div>

        <div className="mt-8 rounded-2xl sm:rounded-3xl border border-white/10 bg-white/5 backdrop-blur shadow-sm overflow-hidden">
          <div className="p-6 md:p-8">

            {loading ? (
              <p className="text-sm text-white/60">Loading...</p>
            ) : (
              <>
                {/* Show who is applying */}
                {profile ? (
                  <div className="flex items-center gap-3 rounded-2xl border border-white/10 bg-black/30 px-4 py-3">
                    <div className="h-9 w-9 rounded-full bg-white/10 flex items-center justify-center text-sm font-bold text-white">
                      {profile.name?.charAt(0)?.toUpperCase() || "?"}
                    </div>
                    <div>
                      <div className="text-sm font-medium text-white">{profile.name}</div>
                      <div className="text-xs text-white/50">Applying as this account</div>
                    </div>
                  </div>
                ) : (
                  <div className="rounded-2xl border border-amber-500/20 bg-amber-500/10 px-4 py-3 text-sm text-amber-200">
                    You are not logged in. Please{" "}
                    <a href="/login" className="underline font-semibold">login</a>{" "}
                    first to apply.
                  </div>
                )}

                {result && (
                  <div
                    className={`mt-6 rounded-2xl border px-4 py-3 text-sm ${
                      result.type === "success"
                        ? "border-emerald-500/20 bg-emerald-500/10 text-emerald-200"
                        : result.type === "not_logged_in"
                        ? "border-amber-500/20 bg-amber-500/10 text-amber-200"
                        : result.type === "not_member"
                        ? "border-blue-500/20 bg-blue-500/10 text-blue-200"
                        : "border-red-500/20 bg-red-500/10 text-red-200"
                    }`}
                  >
                    <div className="leading-relaxed">{result.message}</div>

                    {result.type === "not_member" && (
                      <div className="mt-4">
                        <a
                          href="/register"
                          className="inline-flex items-center justify-center rounded-2xl px-4 py-2 font-semibold bg-white text-black hover:bg-white/90 transition"
                        >
                          Become a Member
                        </a>
                      </div>
                    )}
                  </div>
                )}

                {result?.type !== "success" && (
                  <button
                    onClick={submit}
                    disabled={!profile || submitting}
                    className={[
                      "mt-6 w-full px-4 sm:px-6 py-3 rounded-2xl font-semibold transition",
                      profile && !submitting
                        ? "bg-white text-black hover:bg-white/90 shadow-sm"
                        : "bg-white/10 border border-white/10 cursor-not-allowed text-white/60 shadow-none",
                    ].join(" ")}
                    type="button"
                  >
                    {submitting ? "Submitting..." : "Apply Now"}
                  </button>
                )}

                <p className="mt-3 text-xs text-white/55">
                  Payment will be handled personally after approval.
                </p>
              </>
            )}
          </div>

          <div className="border-t border-white/10 bg-black/20 px-4 sm:px-6 py-4 text-xs text-white/60">
            If you applied already, you'll see a confirmation message. Admin will respond soon.
          </div>
        </div>
      </div>
    </main>
  );
}